//menu do site!
MENU = () =>{
 const menu = document.querySelector('.menu')
 menu.innerHTML = `
  <ul class="menu-ul">
      <li><a href="#">Home</a></li>
      <li><a href="#servico">Serviços</a></li>
      <li><a href="#cursos">Cusos</a></li>
      <li><a href="#contato">Contato</a></li>
      <li><a href="#sobre">Sobre</a></li>
  </ul>
 `
}
MENU()

//Validação do formulário
 
window.onload = () => {
 // declaração da variável do botão submit
 const Enviar = document.getElementById('Enviar')
 
 Enviar.onclick = () => {
  /* declaração das variáveis dos campos do formulário todoo
  */
 const email = document.getElementById('email').value
  const assunto = document.getElementById('assunto').value
  const sms = document.getElementById('sms').value
  const small1 = document.getElementById('small1')
  const small2 = document.getElementById('small2')
  const small3 = document.getElementById('small3')
 // campo email
   if(email == ''){
    small1.innerHTML = 'Preencha este campo...'
    return email
   }else{
    localStorage.email = email
   }
   //campo assunto
   if(assunto == ''){
    small2.innerHTML = 'Preencha este campo...'
    return assunto
   }else{
    localStorage.assunto = assunto
   }
   // campo sms
   if(sms == ''){
    small3.innerHTML = 'Preencha este campo...'
    return sms
   }else{
    localStorage.sms = sms
   }
   //mensagem do envio dos dados
   if (email == '' && assunto == '' && sms == '') {
    alert('Verifique os seus dados ou prreencha todo formulário e tente novamente!')
    
   }else{
    alert('[PARABÉNS] – Os seus dados form enviados com sucessos!')
   }
 }
}
